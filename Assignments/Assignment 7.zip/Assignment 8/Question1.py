from pyspark import SparkConf, SparkContext

def main(sc):
    #Loads the file "integer_list" into the variable ffile
    ffile = sc.textFile("/user/amir/integer_list.txt")
    
    #Converts the textfile into integer values
    num = ffile.map(lambda x:int(x))
    
    #Separates the even and odd numbers
    even = num.filter(lambda x: x%2==0)
    odd = num.filter(lambda x:x%2==1)

    #Creates strings in order to display the results
    even_string = "The number of even numbers is " + str(even.count())
    odd_string = "The number of odd numbers is " + str(odd.count())

    #Converts the strings into a RDD and saves the results
    result = sc.parallelize([even_string,odd_string])
    result.saveAsTextFile("/user/amir/odd_even_count")
    
    
    




if __name__  == "__main__":
    conf = SparkConf().setAppName("MyAppp")
    sc = SparkContext(conf = conf)
    main(sc)
    sc.stop()
