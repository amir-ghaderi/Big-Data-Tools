from pyspark import SparkConf, SparkContext

def main(sc):
    #Load the file into a variable called ffile
    ffile = sc.textFile("/user/amir/shakespeare_100.txt")

    #splits the lines on spaces
    wordList = ffile.flatMap(lambda line: line.split())

    #Converts each word into a tuple with a 1 value
    wordCount = wordList.map(lambda word: (word,1))

    #Aggregates the values for each unique word
    wordsWithTotalCount = wordCount.reduceByKey(lambda v1, v2: v1+v2)

    #Gets 10 words with the higest counts
    top_ten = wordsWithTotalCount.takeOrdered(10,lambda (word,value): -1 *value)

    #Sorts the RDD in ascending order
    sort_RDD = wordsWithTotalCount.sortBy(lambda (word,count):count)
    
    #Gets the first 10 elements, which are the words with the least count
    bottom_ten = sort_RDD.take(10) # gives the least 10

    #Combines the result into a RDD
    result = sc.parallelize([top_ten,bottom_ten])

    #Saves the result into HDFS
    result.saveAsTextFile("/user/amir/top_k_word")

if __name__  == "__main__":
    conf = SparkConf().setAppName("MyApp")
    sc = SparkContext(conf = conf)
    main(sc)
    sc.stop()
