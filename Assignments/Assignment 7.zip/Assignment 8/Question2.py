from pyspark import SparkConf, SparkContext


#Creates a tuple fucntion where department is a string and salary is a integer 
def makeTuple(line):
    words = line.split()
    return (words[0], int(words[1]))

def main(sc):
    #Loads the file into a variable called ffile
    ffile = sc.textFile("/user/amir/dept_salary.txt")

    #Calls the tuple function above on each element in the variable ffile
    wordList = ffile.map(lambda line: makeTuple(line))

    #Combines all salaries on their respective department
    sumCount = wordList.reduceByKey(lambda x,y: x+y)

    #saves the result into a text file inside hdfs
    sumCount.saveAsTextFile("/user/amir/sum_count")

if __name__  == "__main__":
    conf = SparkConf().setAppName("MyApp")
    sc = SparkContext(conf = conf)
    main(sc)
    sc.stop()
