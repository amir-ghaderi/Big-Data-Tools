#!/usr/bin/env python

import sys
from operator import itemgetter

current_word = None
current_min = 0

for i in sys.stdin:
    i = i.strip()
    word, income = i.split('\t',1)
    
    try:
        income = int(income)
    except ValueError:
        continue

    if word == current_word:
        if int(income) < current_min:
            current_min = int(income)
    else:
        if current_word:
            print '%s\t%s' % (current_word, current_min)
        current_word = word
        current_min = int(income)
    
print '%s\t%s' % (current_word, current_min)

