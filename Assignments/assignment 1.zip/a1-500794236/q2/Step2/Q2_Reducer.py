#!/usr/bin/env python

from operator import itemgetter
import sys

current_dic = {}



for i in sys.stdin:
    i = i.strip()
    word, count = i.split('\t', 1)

    try:
        count = int(count)
    except ValueError:
        continue

    current_dic[word] = int(count)

sortedlist = sorted(current_dic.items(), key = lambda t:t[1])

for i in range(1,11):
    print '%s\t%s' % (sortedlist[-i][0],sortedlist[-i][1])

    
