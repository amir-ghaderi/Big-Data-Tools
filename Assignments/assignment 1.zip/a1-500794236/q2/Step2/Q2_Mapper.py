#!/usr/bin/env python

import sys

for i in sys.stdin:
    i = i.strip()
    word = i.split()
    if len(word) == 2:
        try:
            print '%s\t%s' % (word[0],word[1])
        except:
            continue

        
    
    
