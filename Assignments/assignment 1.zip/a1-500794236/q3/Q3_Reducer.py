#!/usr/bin/env python

from operator import itemgetter
import sys

for i in sys.stdin:
    i = i.strip()
    sid,dep,course = i.split("\t",2)
    
    try:
    	sid=int(sid)
    except ValueError:
    	continue
    
    if dep == "QA" or course == "Math":
        print "%s\t%s\t%s" % (sid,dep,course)


