#!/usr/bin/env python

import sys

for i in sys.stdin:
    i = i.strip()
    word = i.split(',',2)
    if len(word) == 3:
        try:
            print '%s\t%s\t%s' % (word[0],word[1],word[2])
        except:
            continue


        
