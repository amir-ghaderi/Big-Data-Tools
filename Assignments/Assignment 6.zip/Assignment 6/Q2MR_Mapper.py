#!/usr/bin/env python

import sys

for i in sys.stdin:
    i = i.strip()
    word = i.split('\t')
    if len(word) == 5:
        try:
            print '%s\t%s\t%s' % (word[2], word[0],word[3])
        except:
            continue
    if len(word) < 5:
        try:
            print '%s\t%s\t%s' % (word[1], word[0],word[2])
        except:
            continue
        
