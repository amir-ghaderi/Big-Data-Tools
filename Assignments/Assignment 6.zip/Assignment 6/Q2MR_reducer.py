#!/usr/bin/env python

from operator import itemgetter
import sys


A=[]
B=[]
current_movieid = 1

for i in sys.stdin:
    i = i.strip()
    movieid, ab, rating_name = i.split('\t',2)

    try:
        movieid = int(movieid)
    except ValueError:
        continue
    

    if int(movieid) != current_movieid:
        for i in A:
            print '%s\t%s' % (B[0],i)
        A=[]
        B=[]
        
    if ab == "A":
        if int(rating_name) > 3:
            A.append(rating_name)
    if ab == "B":
        B.append(rating_name)

    current_movieid = int(movieid)

for i in A:
    print '%s\t%s' % (B[0],i)
    

    
