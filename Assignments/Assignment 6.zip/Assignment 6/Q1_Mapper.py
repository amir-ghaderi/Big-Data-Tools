#!/usr/bin/env python

import sys

for i in sys.stdin:
    i = i.strip()
    word = i.split('\t')
    if len(word) <= 4:
        try:
            print '%s\t%s' % (word[1], word[2])
        except:
            continue 
            
