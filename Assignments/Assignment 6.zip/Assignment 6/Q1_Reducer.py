#!/usr/bin/env python

from operator import itemgetter
import sys

for i in sys.stdin:
    i = i.strip()
    movieid, rating = i.split('\t',1)

    try:
        rating = int(rating)
    except ValueError:
        continue

    if int(rating) > 3:
        print '%s\t%s' % (movieid, rating)
        
        
